const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/subscriptions', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

const SubscriptionSchema = new mongoose.Schema({
  name: String,
  cost: Number,
  renewalDate: Date,
  category: String
});

const Subscription = mongoose.model('Subscription', SubscriptionSchema);

app.get('/subscriptions', async (req, res) => {
  const subs = await Subscription.find();
  res.json(subs);
});

app.post('/subscriptions', async (req, res) => {
  const sub = new Subscription(req.body);
  await sub.save();
  res.json(sub);
});

app.delete('/subscriptions/:id', async (req, res) => {
  await Subscription.findByIdAndDelete(req.params.id);
  res.json({ message: 'Deleted' });
});

app.listen(5000, () => {
  console.log('Server is running on http://localhost:5000');
});
